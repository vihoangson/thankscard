-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.1.13-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win32
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for thankscard
CREATE DATABASE IF NOT EXISTS `thankscard` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `thankscard`;


-- Dumping structure for table thankscard.admin
CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `admin_login` varchar(50) DEFAULT NULL,
  `admin_password` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table thankscard.admin: ~0 rows (approximately)
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`admin_id`, `admin_login`, `admin_password`) VALUES
	(1, 'admin', 'e10adc3949ba59abbe56e057f20f883e');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;


-- Dumping structure for table thankscard.comment
CREATE TABLE IF NOT EXISTS `comment` (
  `comment_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) DEFAULT NULL,
  `comment_content` varchar(50) DEFAULT NULL,
  `comment_who_thank` varchar(50) DEFAULT NULL,
  `active` int(11) DEFAULT NULL,
  `comment_reg_datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`comment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- Dumping data for table thankscard.comment: ~8 rows (approximately)
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` (`comment_id`, `user_id`, `comment_content`, `comment_who_thank`, `active`, `comment_reg_datetime`) VALUES
	(1, '1', 'adqwe', 'son', NULL, '2016-12-08 09:34:04'),
	(2, '1', '513512312', 'son', NULL, '2016-12-08 09:34:08'),
	(3, '2', '6875678', 'son', NULL, '2016-12-08 09:53:38'),
	(4, '4', '568678', 'son', NULL, '2016-12-08 09:53:52'),
	(5, '2', '07896789', 'son', NULL, '2016-12-08 09:53:56'),
	(6, '1', '5678678', 'son', NULL, '2016-12-08 09:54:01'),
	(7, '2', '5678569', 'son', NULL, '2016-12-08 09:54:05'),
	(8, '1', '4657458458', 'son', NULL, '2016-12-08 09:55:17');
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;


-- Dumping structure for table thankscard.user
CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_eid` varchar(50) DEFAULT NULL,
  `user_nick_name` varchar(50) DEFAULT NULL,
  `user_img` varchar(50) NOT NULL,
  `user_gwid` varchar(50) DEFAULT NULL,
  `user_reg_datetime` datetime DEFAULT NULL,
  `active` varchar(50) DEFAULT '1',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

-- Dumping data for table thankscard.user: ~2 rows (approximately)
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`user_id`, `user_eid`, `user_nick_name`, `user_img`, `user_gwid`, `user_reg_datetime`, `active`) VALUES
	(1, '5135623623', 'son', '.jpg', '23474567', '2016-12-08 09:44:41', '1'),
	(4, '785785768', 'r6tfu  26', '.png', '34560789568', '2016-12-08 09:44:41', '1'),
	(24, '68688956', 'asd', '.jpg', 'fasd', '2016-12-08 10:58:33', '1');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
